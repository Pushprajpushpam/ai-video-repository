
import openai
import os
from gtts import gTTS
from moviepy.editor import *
import requests
import streamlit as st

# Set your OpenAI and Pexels API Keys
openai.api_key = st.secrets["OPENAI_API_KEY"]
PEXELS_API_KEY = st.secrets["PEXELS_API_KEY"]

def generate_script(topic):
    prompt = f"Create a short 60-second script for an educational video about {topic}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()

def text_to_speech(text, filename="voice.mp3"):
    tts = gTTS(text)
    tts.save(filename)
    return filename

def download_images_from_pexels(query, count=5):
    headers = {
        "Authorization": PEXELS_API_KEY
    }
    params = {
        "query": query,
        "per_page": count
    }
    response = requests.get("https://api.pexels.com/v1/search", headers=headers, params=params)
    data = response.json()

    image_files = []
    for i, photo in enumerate(data.get("photos", [])):
        url = photo["src"]["landscape"]
        image_data = requests.get(url).content
        filename = f"image_{i}.jpg"
        with open(filename, "wb") as f:
            f.write(image_data)
        image_files.append(filename)

    return image_files

def create_video(images, audio_file, output_file="final_video.mp4"):
    clips = []
    duration_per_image = AudioFileClip(audio_file).duration / len(images)

    for img in images:
        clip = ImageClip(img).set_duration(duration_per_image)
        clips.append(clip)

    video = concatenate_videoclips(clips, method="compose")
    audio = AudioFileClip(audio_file)
    final = video.set_audio(audio)
    final.write_videofile(output_file, fps=24)
    return output_file

# Streamlit UI
st.title("AI-Powered Video Creator")
topic = st.text_input("Enter a topic for the video:")

if st.button("Generate Video") and topic:
    try:
        with st.spinner("Generating script..."):
            script = generate_script(topic)
            st.write("**Script:**")
            st.text(script)

        with st.spinner("Creating voiceover..."):
            audio_file = text_to_speech(script)

        with st.spinner("Downloading images..."):
            images = download_images_from_pexels(topic)

        with st.spinner("Creating video..."):
            video_path = create_video(images, audio_file)

        st.success("Video created successfully!")
        st.video(video_path)
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
